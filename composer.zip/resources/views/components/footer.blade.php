<footer class="bg-transparent backdrop-blur-sm py-8 border-t">
    <div class="container mx-auto px-5 text-center">
        <div class="text-sm pb-16 md:pb-0">
            <p><i class="fa-solid fa-copyright mr-1"></i>2025 WeInvite | All rights reserved</p>
            <p class="pt-2">Develop with <i class="fa-solid fa-heart text-red-500"></i> by Ikhsan Permana Hadiansyah</p>
        </div>
    </div>
</footer>
