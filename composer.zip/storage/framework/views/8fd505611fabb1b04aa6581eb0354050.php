<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Bottom Navbar -->
    <div class="fixed bottom-0 left-0 right-0 z-30 bg-white border-t border-gray-200">
        <div id="bottom-navbar" class="flex overflow-x-auto whitespace-nowrap justify-around items-center py-2">
            <button id="scroll-left"
                class="absolute left-1 top-[38%] -translate-y-1/2 z-10 text-white bg-gray-800 hover:bg-black p-2 shadow-lg rounded hidden">
                <i class="fas fa-chevron-left"></i>
            </button>
            <button id="scroll-right"
                class="absolute right-1 top-[38%] -translate-y-1/2 z-10 text-white bg-gray-800 hover:bg-black p-2 shadow-lg rounded hidden">
                <i class="fas fa-chevron-right"></i>
            </button>

            <a href="#pengantin" class="flex flex-col items-center text-gray-500 hover:text-gray-800 min-w-[64px] mx-4">
                <i class="fa-solid fa-heart text-lg"></i>
                <span class="text-xs">Pengantin</span>
            </a>
            <a href="#acara" class="flex flex-col items-center text-gray-500 hover:text-gray-800 min-w-[64px] mx-4">
                <i class="fa-solid fa-clock text-lg"></i>
                <span class="text-xs">Acara</span>
            </a>
            <?php if($isPremium): ?>
                <a href="#streaming"
                    class="flex flex-col items-center text-gray-500 hover:text-gray-800 min-w-[64px] mx-4">
                    <i class="fas fa-broadcast-tower text-lg"></i>
                    <span class="text-xs">Streaming</span>
                </a>
            <?php endif; ?>
            <a href="#foto-video"
                class="flex flex-col items-center text-gray-500 hover:text-gray-800 min-w-[64px] mx-4">
                <i class="fa-solid fa-photo-film text-lg"></i>
                <span class="text-xs">Foto & Video</span>
            </a>
            <a href="#cerita" class="flex flex-col items-center text-gray-500 hover:text-gray-800 min-w-[64px] mx-4">
                <i class="fas fa-book-open text-lg"></i>
                <span class="text-xs">Cerita</span>
            </a>
            <a href="#quote" class="flex flex-col items-center text-gray-500 hover:text-gray-800 min-w-[64px] mx-4">
                <i class="fas fa-quote-right text-lg"></i>
                <span class="text-xs">Quote</span>
            </a>
            <?php if($isPremium): ?>
                <a href="#kado-digital"
                    class="flex flex-col items-center text-gray-500 hover:text-gray-800 min-w-[64px] mx-4">
                    <i class="fas fa-gift text-lg"></i>
                    <span class="text-xs">Kado Digital</span>
                </a>
            <?php endif; ?>
            <a href="#musik" class="flex flex-col items-center text-gray-500 hover:text-gray-800 min-w-[64px] mx-4">
                <i class="fas fa-music text-lg"></i>
                <span class="text-xs">Musik</span>
            </a>
            <a href="#tamu" class="flex flex-col items-center text-gray-500 hover:text-gray-800 min-w-[64px] mx-4">
                <i class="fas fa-user-friends text-lg"></i>
                <span class="text-xs">Tamu</span>
            </a>
            <?php if($isPremium): ?>
                <a href="#ucapan-doa"
                    class="flex flex-col items-center text-gray-500 hover:text-gray-800 min-w-[64px] mx-4">
                    <i class="fa-solid fa-comment-dots text-lg"></i>
                    <span class="text-xs">Ucapan & Doa</span>
                </a>
            <?php endif; ?>
            <a href="#teks" class="flex flex-col items-center text-gray-500 hover:text-gray-800 min-w-[64px] mx-4">
                <i class="fa-solid fa-file-lines text-lg"></i>
                <span class="text-xs">Teks</span>
            </a>
            <a href="#tema" class="flex flex-col items-center text-gray-500 hover:text-gray-800 min-w-[64px] mx-4">
                <i class="fas fa-palette text-lg"></i>
                <span class="text-xs">Tema</span>
            </a>
        </div>
    </div>
    <!-- Tombol Navigasi Up & Down -->
    <div class="fixed bottom-24 md:bottom-20 right-2 z-30 flex flex-col space-y-2">
        <!-- Tombol ke Atas -->
        <a id="scroll-up-btn" href="#" onclick="scrollToTop(); return false;"
            class="bg-gray-800 text-white rounded-full p-3 shadow-lg hover:bg-black transition-colors hidden">
            <i class="fas fa-arrow-up text-lg"></i>
        </a>

        <!-- Tombol ke Bawah -->
        <a id="scroll-down-btn" href="#" onclick="scrollToBottom(); return false;"
            class="bg-gray-800 text-white rounded-full p-3 shadow-lg hover:bg-black transition-colors hidden">
            <i class="fas fa-arrow-down text-lg"></i>
        </a>
    </div>
    <!-- Konten -->
    <div class="mx-auto px-2 md:px-4 pb-24 pt-[1rem] md:pt-10">
        <!-- Flash Message -->
        <div>
            <?php if(session('success')): ?>
                <div id="successModal" tabindex="-1" aria-hidden="true"
                    class="fixed inset-0 z-50 flex items-center justify-center bg-black/80 hidden">
                    <div class="relative p-4 w-full max-w-md h-auto md:h-auto opacity-0 scale-50">
                        <div class="relative p-4 text-center bg-white rounded-lg shadow sm:p-5">
                            <button type="button"
                                class="text-gray-900 absolute top-2.5 right-2.5 bg-gray-100 hover:bg-gray-200 hover:text-green-500 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center"
                                onclick="closeModal('successModal')">
                                <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd"
                                        d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                        clip-rule="evenodd"></path>
                                </svg>
                                <span class="sr-only">Close modal</span>
                            </button>
                            <br>
                            <div
                                class="w-20 h-20 rounded-full bg-green-100 p-2 flex items-center justify-center mx-auto mb-3.5 mt-3.5">
                                <svg aria-hidden="true" class="w-8 h-8 text-green-500" fill="currentColor"
                                    viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd"
                                        d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                                        clip-rule="evenodd"></path>
                                </svg>
                            </div>
                            <h2 class="mb-4 text-gray-900 text-lg font-bold">
                                BERHASIL
                            </h2>
                            <p class="mb-4 text-gray-900">
                                <?php echo e(session('success')); ?>

                            </p>
                        </div>
                    </div>
                </div>
            <?php elseif(session('error')): ?>
                <div id="errorModal" tabindex="-1" aria-hidden="true"
                    class="flex justify-center items-center fixed inset-0 z-50 bg-black/80 hidden">
                    <div class="relative p-4 w-full max-w-md h-auto md:h-auto opacity-0 scale-50">
                        <div class="relative p-4 text-center bg-white rounded-lg shadow sm:p-5">
                            <button type="button"
                                class="text-gray-900 absolute top-2.5 right-2.5 bg-gray-100 hover:bg-gray-200 hover:text-red-500 rounded-lg text-sm p-1.5 ml-auto inline-flex items-center"
                                onclick="closeModal('errorModal')">
                                <svg aria-hidden="true" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd"
                                        d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                        clip-rule="evenodd"></path>
                                </svg>
                                <span class="sr-only">
                                    Close modal
                                </span>
                            </button>
                            <br>
                            <div
                                class="w-20 h-20 rounded-full bg-red-100 p-2 flex items-center justify-center mx-auto mb-3.5 mt-3.5">
                                <svg aria-hidden="true" class="w-8 h-8 text-red-500" fill="currentColor"
                                    viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd" d="M6 18L18 6M6 6l12 12" stroke="currentColor"
                                        stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                </svg>
                            </div>
                            <h2 class="mb-4 text-gray-900 text-lg font-bold">
                                ERROR
                            </h2>
                            <p class="mb-4 text-gray-900">
                                <?php echo e(session('error')); ?>

                            </p>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <!-- Data Undangan -->
        <section class="py-8 antialiased mx-auto md:py-16">
            <!-- Pengantin -->
            <?php echo $__env->make('partials.pengantin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Acara -->
            <?php echo $__env->make('partials.acara', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Streaming -->
            <?php echo $__env->make('partials.streaming', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Galeri -->
            <?php echo $__env->make('partials.galeri', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Cerita -->
            <?php echo $__env->make('partials.cerita', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Quotes -->
            <?php echo $__env->make('partials.quote', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Kado Digital -->
            <?php echo $__env->make('partials.kado-digital', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Musik -->
            <?php echo $__env->make('partials.musik', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Tamu -->
            <?php echo $__env->make('partials.tamu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Ucapan & Doa -->
            <?php echo $__env->make('partials.ucapan-doa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Teks -->
            <?php echo $__env->make('partials.teks', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Tema -->
            <?php echo $__env->make('partials.tema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <hr class="border-t border-gray-800 my-5">
            <!-- Tombol Preview -->
            <div class="flex justify-center">
                <a href="<?php echo e(route('user.invitation.show', $invitation->slug)); ?>" target="_blank"
                    class="bg-gray-800 hover:bg-black text-white shadow-lg font-bold py-2 px-6 rounded focus:outline-none focus:ring-2 focus:ring-gray-800 focus:ring-offset-2 transition ease-in-out duration-150">
                    <i class="fa-solid fa-envelope-open mr-2"></i>
                    <span class="mr-2">Preview</span>
                </a>
            </div>
        </section>
        <div class="my-8 px-6 lg:px-8">
            <div class="max-w-4xl mx-auto">
                <div class="bg-white rounded-lg shadow-lg overflow-hidden border">
                    <div class="p-6">
                        <p class="text-gray-700 text-center mb-6">
                            Sibuk? Tidak mau repot isi data-datanya? Cukup chat Admin! Kirimkan data yang
                            diperlukan,
                            dan Admin akan mengurusnya untuk Anda.
                            Namun, layanan ini tidak gratis ya, hehe <i class="fa-solid fa-face-grin"></i>. Dengan
                            donasi
                            <span class="font-semibold">Rp30.000</span>, Anda tinggal terima beres!
                        </p>
                        <div class="flex justify-center">
                            <a href="https://wa.me/628558359732" target="_blank"
                                class="flex items-center bg-gray-800 hover:bg-black text-white font-bold py-2 px-6 rounded shadow-md transition duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-gray-800 focus:ring-offset-2">
                                <i class="fa-brands fa-whatsapp mr-2 text-xl"></i>
                                <span>Chat Sekarang</span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Herd\undangan\resources\views/user/edit-invitation.blade.php ENDPATH**/ ?>